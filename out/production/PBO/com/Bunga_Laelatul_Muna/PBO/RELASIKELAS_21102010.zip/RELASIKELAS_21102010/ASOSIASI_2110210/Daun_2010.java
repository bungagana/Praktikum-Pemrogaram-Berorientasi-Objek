package com.Bunga_Laelatul_Muna.PBO.RELASIKELAS_21102010.ASOSIASI_2110210;

public class Daun_2010 {
    private String jenis_2010;
    private String warna_2010;

    public Daun_2010(String jenis, String warna) {
        this.jenis_2010 = jenis;
        this.warna_2010 = warna;
    }

    public String getJenis_2010() {
        return jenis_2010;
    }

    public String getWarna_2010() {
        return warna_2010;
    }
}
