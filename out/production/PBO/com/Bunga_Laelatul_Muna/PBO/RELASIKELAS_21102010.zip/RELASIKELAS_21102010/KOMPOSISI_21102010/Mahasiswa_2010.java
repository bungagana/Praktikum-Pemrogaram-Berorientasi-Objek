package com.Bunga_Laelatul_Muna.PBO.RELASIKELAS_21102010.KOMPOSISI_21102010;

public class Mahasiswa_2010 {
    private String nama_2010, npm_2010, angkatan_2010;


    public Mahasiswa_2010(String nama, String npm, String angkatan) {
        this.nama_2010 = nama;
        this.npm_2010 = npm;
        this.angkatan_2010 = angkatan;
    }

    public String getNama() {
        return nama_2010;
    }

    public String getNpm() {
        return npm_2010;
    }

    public String getAngkatan() {
        return angkatan_2010;
    }

}
